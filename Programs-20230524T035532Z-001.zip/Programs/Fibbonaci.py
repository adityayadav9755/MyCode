x=int(input("Enter the maximum no."))
a=0
b=1
c=0
while a<=x:
	print(a)
	c=a+b
	a=b
	b=c