n=int(input("Enter the maximum number of levels."))
a=n
b=1
while n!=0:
	print(" "*(n+a), b,  end="\n")
	b=b*11
	n-=1
	a-=1
TO BE EDITED!!!

