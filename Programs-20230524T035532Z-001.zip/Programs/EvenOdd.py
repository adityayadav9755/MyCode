a= int(input("Enter the number."))
b=a%2
if b==0:
	print("Even.") 
else:
	print("Odd.")
