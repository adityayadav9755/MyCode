n=int(input("side=?"))
i=0
for i in range(0,n):
 print("* "*n)